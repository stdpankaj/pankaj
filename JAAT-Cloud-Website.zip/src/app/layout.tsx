import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "JAAT Cloud — Premium Discord Bot Hosting",
  description: "Enterprise AMD EPYC performance with up to 100Gbps networks, instant cluster setup and 99.9% uptime. Host your Discord bots with JAAT Cloud.",
  keywords: ["Discord Bot Hosting", "JAAT Cloud", "Bot Hosting", "Discord", "VPS", "Game Hosting"],
  authors: [{ name: "JAAT Cloud" }],
  openGraph: {
    title: "JAAT Cloud — Premium Discord Bot Hosting",
    description: "Enterprise AMD EPYC performance with instant setup and 99.9% uptime.",
    siteName: "JAAT Cloud",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "JAAT Cloud — Premium Discord Bot Hosting",
    description: "Enterprise AMD EPYC performance with instant setup and 99.9% uptime.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
