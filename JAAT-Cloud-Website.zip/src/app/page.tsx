"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Shield,
  Zap,
  Clock,
  Server,
  Cpu,
  HardDrive,
  Network,
  Headphones,
  Check,
  X,
  ArrowRight,
  Menu,
  XIcon,
} from "lucide-react";

/* ─── Data ─── */

type PlanTier = "monthly" | "quarterly" | "semi-annual" | "annual";

const priceMultiplier: Record<PlanTier, number> = {
  monthly: 1,
  quarterly: 0.9,
  "semi-annual": 0.8,
  annual: 0.7,
};

interface Plan {
  name: string;
  basePrice: number;
  ram: string;
  cpu: string;
  storage: string;
  port: string;
  bandwidth: string;
  features: string[];
  accent: string;
  badge?: string;
  usagePercent: number;
  usageLabel: string;
  popular?: boolean;
}

const plans: Plan[] = [
  {
    name: "Basic",
    basePrice: 0.67,
    ram: "512MB RAM",
    cpu: "1 vCPU Core",
    storage: "5GB NVMe SSD",
    port: "1Gbps",
    bandwidth: "1TB",
    features: ["DDoS Protection", "1Gbps Port Speed", "Instant Setup", "24/7 Support"],
    accent: "border-blue-500/30 hover:border-blue-500/60",
    usagePercent: 20,
    usageLabel: "Basic Usage",
  },
  {
    name: "Standard",
    basePrice: 1.12,
    ram: "1GB RAM",
    cpu: "1 vCPU Core",
    storage: "10GB NVMe SSD",
    port: "1Gbps",
    bandwidth: "2TB",
    features: ["DDoS Protection", "Full Root Access", "1Gbps Port Speed", "Instant Setup", "24/7 Support"],
    accent: "border-purple-500/30 hover:border-purple-500/60",
    badge: "POPULAR",
    usagePercent: 35,
    usageLabel: "Standard Usage",
    popular: true,
  },
  {
    name: "Premium",
    basePrice: 2.16,
    ram: "2GB RAM",
    cpu: "2 vCPU Cores",
    storage: "25GB NVMe SSD",
    port: "1Gbps",
    bandwidth: "5TB",
    features: ["DDoS Protection", "Full Root Access", "1Gbps Port Speed", "Instant Setup", "24/7 Support"],
    accent: "border-orange-500/30 hover:border-orange-500/60",
    usagePercent: 50,
    usageLabel: "Premium Usage",
  },
  {
    name: "Ultimate",
    basePrice: 3.96,
    ram: "4GB RAM",
    cpu: "4 vCPU Cores",
    storage: "50GB NVMe SSD",
    port: "1Gbps",
    bandwidth: "10TB",
    features: ["DDoS Protection", "Full Root Access", "1Gbps Port Speed", "Instant Setup", "24/7 Support"],
    accent: "border-yellow-500/30 hover:border-yellow-500/60",
    usagePercent: 65,
    usageLabel: "Ultimate Usage",
  },
  {
    name: "Supreme",
    basePrice: 6.55,
    ram: "8GB RAM",
    cpu: "6 vCPU Cores",
    storage: "100GB NVMe SSD",
    port: "10Gbps",
    bandwidth: "Unlimited",
    features: ["DDoS Protection", "Full Root Access", "10Gbps Port Speed", "Instant Setup", "24/7 Support", "Dedicated IP"],
    accent: "border-pink-500/30 hover:border-pink-500/60",
    usagePercent: 80,
    usageLabel: "Supreme Usage",
  },
  {
    name: "Elite",
    basePrice: 11.33,
    ram: "16GB RAM",
    cpu: "8 vCPU Cores",
    storage: "200GB NVMe SSD",
    port: "10Gbps",
    bandwidth: "Unlimited",
    features: ["DDoS Protection", "Full Root Access", "10Gbps Port Speed", "Instant Setup", "24/7 Support", "Dedicated IP", "Backup Service"],
    accent: "border-purple-400/30 hover:border-purple-400/60",
    badge: "BEST VALUE",
    usagePercent: 90,
    usageLabel: "Elite Usage",
  },
];

const comparisonRows = [
  { label: "RAM", values: ["512MB", "1GB", "2GB", "4GB", "8GB", "16GB"] },
  { label: "vCPUs", values: ["1", "1", "2", "4", "6", "8"] },
  { label: "Storage", values: ["5GB", "10GB", "25GB", "50GB", "100GB", "200GB"] },
  { label: "Bandwidth", values: ["1TB", "2TB", "5TB", "10TB", "Unlimited", "Unlimited"] },
  { label: "Port Speed", values: ["1Gbps", "1Gbps", "1Gbps", "1Gbps", "10Gbps", "10Gbps"] },
  { label: "DDoS Protection", values: [true, true, true, true, true, true] },
  { label: "Full Root Access", values: [false, true, true, true, true, true] },
  { label: "Dedicated IP", values: [false, false, false, false, true, true] },
  { label: "Backup Service", values: [false, false, false, false, false, true] },
  { label: "Uptime SLA", values: ["99.9%", "99.9%", "99.9%", "99.9%", "99.95%", "99.99%"] },
];

const navLinks = [
  { label: "Home", href: "#" },
  { label: "Discord Hosting", href: "#pricing" },
  { label: "Minecraft Hosting", href: "#" },
  { label: "Linux VPS", href: "#" },
  { label: "More", href: "#" },
];

/* ─── Components ─── */

function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  return (
    <header className="fixed top-0 left-0 right-0 z-50 border-b border-white/[0.06] bg-[#0a0a0a]/80 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
        <a href="#" className="flex items-center gap-2 text-xl font-bold tracking-tight">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-[#00d4ff] to-[#7b61ff]">
            <Zap className="h-4 w-4 text-white" />
          </div>
          <span>
            JAAT<span className="gradient-text">Cloud</span>
          </span>
        </a>
        <nav className="hidden items-center gap-1 md:flex">
          {navLinks.map((l) => (
            <a
              key={l.label}
              href={l.href}
              className="rounded-md px-3 py-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              {l.label}
            </a>
          ))}
        </nav>
        <div className="hidden items-center gap-3 md:flex">
          <Button variant="ghost" className="text-sm text-muted-foreground hover:text-foreground">
            Login
          </Button>
          <Button className="bg-gradient-to-r from-[#00d4ff] to-[#7b61ff] text-white hover:opacity-90">
            Get Started
          </Button>
        </div>
        <button
          className="text-muted-foreground md:hidden"
          onClick={() => setMobileOpen(!mobileOpen)}
        >
          {mobileOpen ? <XIcon className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>
      {mobileOpen && (
        <div className="border-t border-white/[0.06] bg-[#0a0a0a]/95 px-4 pb-4 md:hidden">
          {navLinks.map((l) => (
            <a
              key={l.label}
              href={l.href}
              className="block rounded-md px-3 py-2.5 text-sm text-muted-foreground hover:text-foreground"
              onClick={() => setMobileOpen(false)}
            >
              {l.label}
            </a>
          ))}
          <div className="mt-3 flex flex-col gap-2">
            <Button variant="ghost" className="w-full justify-center text-sm">
              Login
            </Button>
            <Button className="w-full bg-gradient-to-r from-[#00d4ff] to-[#7b61ff] text-white">
              Get Started
            </Button>
          </div>
        </div>
      )}
    </header>
  );
}

function HeroSection() {
  return (
    <section className="relative min-h-screen overflow-hidden bg-grid pt-24">
      {/* Background glow */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/2 top-0 h-[600px] w-[600px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#00d4ff]/[0.07] blur-[120px]" />
        <div className="absolute right-0 bottom-0 h-[400px] w-[400px] translate-x-1/4 translate-y-1/4 rounded-full bg-[#7b61ff]/[0.05] blur-[100px]" />
      </div>
      <div className="relative mx-auto flex max-w-7xl flex-col items-center px-4 py-20 text-center sm:px-6 lg:py-32">
        {/* Breadcrumb */}
        <p className="mb-6 text-xs tracking-wider text-muted-foreground">
          Get Started &gt; Discord &gt;{" "}
          <span className="text-[#00d4ff]">Discord Bot Hosting</span>
        </p>

        {/* Heading */}
        <h1 className="max-w-4xl text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl md:text-6xl lg:text-7xl">
          Discord Bot Hosting{" "}
          <span className="gradient-text">24/7</span>
        </h1>
        <p className="mt-4 max-w-2xl text-lg font-medium text-[#00d4ff] sm:text-xl md:text-2xl">
          Latest Architectures & Unmatched Performance
        </p>

        {/* Subtitle */}
        <p className="mt-6 max-w-2xl text-sm leading-relaxed text-muted-foreground sm:text-base">
          Enterprise AMD EPYC performance on up to 100Gbps unmetered networks
          with instant cluster setup and 99.9% uptime guaranteed.
        </p>

        {/* Trust indicators */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-4 text-sm text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <Shield className="h-4 w-4 text-[#00d4ff]" /> Trusted by 10,000+ customers worldwide
          </span>
          <span className="hidden h-4 w-px bg-white/10 sm:block" />
          <span className="flex items-center gap-1.5">
            <Headphones className="h-4 w-4 text-[#00d4ff]" /> 24/7 Expert Support
          </span>
          <span className="hidden h-4 w-px bg-white/10 sm:block" />
          <span className="flex items-center gap-1.5">
            <Zap className="h-4 w-4 text-[#00d4ff]" /> Instant Setup
          </span>
        </div>

        {/* CTA Buttons */}
        <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
          <a href="#pricing">
            <Button
              size="lg"
              className="bg-gradient-to-r from-[#00d4ff] to-[#7b61ff] px-8 text-base font-semibold text-white shadow-lg shadow-[#00d4ff]/20 hover:opacity-90 hover:shadow-[#00d4ff]/30"
            >
              Buy Now <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </a>
          <Button
            size="lg"
            variant="outline"
            className="border-white/10 px-8 text-base font-semibold hover:border-white/20 hover:bg-white/5"
          >
            Chat With Us
          </Button>
        </div>

        {/* Discord Logo Visual */}
        <div className="relative mt-16">
          <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-[#5865F2]/20 to-[#7b61ff]/20 blur-3xl" />
          <div className="relative flex h-32 w-32 items-center justify-center rounded-3xl bg-gradient-to-br from-[#5865F2] to-[#4752C4] shadow-2xl shadow-[#5865F2]/20 sm:h-40 sm:w-40">
            <svg className="h-16 w-16 text-white sm:h-20 sm:w-20" viewBox="0 0 24 24" fill="currentColor">
              <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03z" />
            </svg>
          </div>
        </div>
      </div>
    </section>
  );
}

function PricingSection() {
  const [tier, setTier] = useState<PlanTier>("monthly");
  const [filter, setFilter] = useState<string>("ALL");

  const filteredPlans =
    filter === "ALL" ? plans : plans.filter((p) => p.name.toUpperCase() === filter);

  return (
    <section id="pricing" className="relative bg-grid py-20">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/2 top-1/2 h-[500px] w-[500px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#7b61ff]/[0.04] blur-[120px]" />
      </div>
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        {/* Section Header */}
        <div className="text-center">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            Pricing <span className="gradient-text">Plans</span>
          </h2>
          <p className="mt-3 text-muted-foreground">
            Choose the perfect plan for your Discord bot
          </p>
        </div>

        {/* Billing Toggle */}
        <div className="mt-10 flex flex-col items-center gap-4">
          <div className="inline-flex items-center rounded-xl border border-white/[0.06] bg-white/[0.02] p-1">
            {(["monthly", "quarterly", "semi-annual", "annual"] as PlanTier[]).map((t) => (
              <button
                key={t}
                onClick={() => setTier(t)}
                className={`rounded-lg px-4 py-2 text-xs font-semibold tracking-wider transition-all sm:px-5 sm:text-sm ${
                  tier === t
                    ? "bg-gradient-to-r from-[#00d4ff] to-[#7b61ff] text-white shadow-lg shadow-[#00d4ff]/20"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {t.toUpperCase()}
              </button>
            ))}
          </div>

          {/* Filter Tags */}
          <div className="flex flex-wrap items-center justify-center gap-2">
            {["ALL", "BASIC", "STANDARD", "PREMIUM", "ULTIMATE"].map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`rounded-full border px-3 py-1 text-xs font-medium transition-all ${
                  filter === f
                    ? "border-[#00d4ff]/40 bg-[#00d4ff]/10 text-[#00d4ff]"
                    : "border-white/[0.06] text-muted-foreground hover:border-white/20 hover:text-foreground"
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        {/* Pricing Cards Grid */}
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filteredPlans.map((plan) => {
            const price = (plan.basePrice * priceMultiplier[tier]).toFixed(2);
            return (
              <div
                key={plan.name}
                className={`card-glass card-glass-hover group relative rounded-2xl border ${plan.accent} p-6 transition-all duration-300 ${
                  plan.popular ? "ring-1 ring-purple-500/20" : ""
                }`}
              >
                {plan.badge && (
                  <Badge
                    className={`absolute -top-3 left-4 ${
                      plan.badge === "BEST VALUE"
                        ? "bg-gradient-to-r from-purple-500 to-purple-600"
                        : "bg-gradient-to-r from-[#00d4ff] to-[#7b61ff]"
                    } text-[10px] font-bold text-white`}
                  >
                    {plan.badge}
                  </Badge>
                )}

                <div className="mb-4 flex items-end justify-between">
                  <div>
                    <h3 className="text-lg font-bold">{plan.name}</h3>
                    <div className="mt-1 flex items-baseline gap-1">
                      <span className="text-3xl font-extrabold">${price}</span>
                      <span className="text-xs text-muted-foreground">/mo</span>
                    </div>
                  </div>
                  <div className={`h-10 w-10 rounded-lg bg-gradient-to-br ${
                    plan.name === "Basic"
                      ? "from-blue-500/20 to-blue-600/10"
                      : plan.name === "Standard"
                      ? "from-purple-500/20 to-purple-600/10"
                      : plan.name === "Premium"
                      ? "from-orange-500/20 to-orange-600/10"
                      : plan.name === "Ultimate"
                      ? "from-yellow-500/20 to-yellow-600/10"
                      : plan.name === "Supreme"
                      ? "from-pink-500/20 to-pink-600/10"
                      : "from-purple-400/20 to-purple-500/10"
                  } flex items-center justify-center`}>
                    <Server className="h-5 w-5 text-muted-foreground" />
                  </div>
                </div>

                {/* Spec highlights */}
                <div className="mb-4 grid grid-cols-3 gap-2 rounded-xl bg-white/[0.02] p-3">
                  <div className="text-center">
                    <Cpu className="mx-auto mb-1 h-3.5 w-3.5 text-muted-foreground" />
                    <p className="text-[11px] font-semibold">{plan.cpu}</p>
                  </div>
                  <div className="text-center">
                    <HardDrive className="mx-auto mb-1 h-3.5 w-3.5 text-muted-foreground" />
                    <p className="text-[11px] font-semibold">{plan.storage}</p>
                  </div>
                  <div className="text-center">
                    <Network className="mx-auto mb-1 h-3.5 w-3.5 text-muted-foreground" />
                    <p className="text-[11px] font-semibold">{plan.port}</p>
                  </div>
                </div>

                {/* Features list */}
                <ul className="mb-5 space-y-2">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Check className="h-3.5 w-3.5 shrink-0 text-[#00d4ff]" />
                      {f}
                    </li>
                  ))}
                </ul>

                {/* Usage bar */}
                <div className="mb-5">
                  <div className="mb-1 flex items-center justify-between text-[10px] text-muted-foreground">
                    <span>{plan.usageLabel}</span>
                    <span>{plan.usagePercent}%</span>
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/[0.05]">
                    <div
                      className="progress-bar-fill h-full rounded-full transition-all"
                      style={{ width: `${plan.usagePercent}%` }}
                    />
                  </div>
                </div>

                {/* CTA */}
                <Button
                  className={`w-full font-semibold ${
                    plan.popular
                      ? "bg-gradient-to-r from-[#00d4ff] to-[#7b61ff] text-white hover:opacity-90"
                      : "border border-white/10 bg-white/[0.03] text-foreground hover:bg-white/[0.06]"
                  }`}
                >
                  Choose {plan.name}
                </Button>
              </div>
            );
          })}
        </div>

        {/* Custom Plan Card */}
        {filter === "ALL" && (
          <div className="mt-6 card-glass card-glass-hover rounded-2xl border border-white/[0.06] p-6 transition-all duration-300 sm:p-8">
            <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
              <div className="flex-1">
                <div className="flex items-center gap-3">
                  <h3 className="text-xl font-bold">Custom Plan</h3>
                  <Badge variant="outline" className="text-[10px]">
                    Flexible Configuration
                  </Badge>
                </div>
                <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted-foreground">
                  Build your perfect server with custom specs including RAM, CPU, storage, and
                  bandwidth tailored to your needs. Up to 100Gbps port speed with 99.99% uptime SLA.
                </p>
              </div>
              <Button variant="outline" className="border-white/10 px-6 font-semibold hover:border-white/20 hover:bg-white/5">
                Contact Sales
              </Button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

function ComparisonSection() {
  return (
    <section className="relative bg-grid py-20">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute right-0 top-0 h-[400px] w-[400px] translate-x-1/3 -translate-y-1/3 rounded-full bg-[#00d4ff]/[0.04] blur-[100px]" />
      </div>
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <div className="text-center">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            Compare <span className="gradient-text">All Plans</span>
          </h2>
          <p className="mt-3 text-muted-foreground">
            See full comparison of all features across plans
          </p>
        </div>

        <div className="mt-12 overflow-x-auto rounded-2xl border border-white/[0.06]">
          <table className="w-full min-w-[700px]">
            <thead>
              <tr className="border-b border-white/[0.06]">
                <th className="px-4 py-4 text-left text-sm font-semibold text-muted-foreground sm:px-6">
                  Feature
                </th>
                {plans.map((p) => (
                  <th
                    key={p.name}
                    className={`px-3 py-4 text-center text-xs font-bold ${
                      p.popular ? "text-[#00d4ff]" : "text-foreground"
                    }`}
                  >
                    {p.name}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {comparisonRows.map((row, i) => (
                <tr
                  key={row.label}
                  className={`border-b border-white/[0.04] ${
                    i % 2 === 0 ? "bg-white/[0.01]" : ""
                  }`}
                >
                  <td className="px-4 py-3.5 text-sm font-medium text-muted-foreground sm:px-6">
                    {row.label}
                  </td>
                  {row.values.map((val, j) => (
                    <td key={j} className="px-3 py-3.5 text-center text-sm">
                      {typeof val === "boolean" ? (
                        val ? (
                          <Check className="mx-auto h-4 w-4 text-[#00d4ff]" />
                        ) : (
                          <X className="mx-auto h-4 w-4 text-muted-foreground/30" />
                        )
                      ) : (
                        <span className={typeof val === "string" && val.includes("Unlimited") ? "font-semibold text-[#00d4ff]" : "text-foreground/80"}>
                          {val}
                        </span>
                      )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}

function FeaturesSection() {
  const features = [
    {
      icon: <Cpu className="h-6 w-6" />,
      title: "AMD EPYC Processors",
      desc: "Latest generation AMD EPYC servers delivering enterprise-grade performance for your bots with industry-leading core counts and clock speeds.",
    },
    {
      icon: <Shield className="h-6 w-6" />,
      title: "DDoS Protection",
      desc: "Enterprise-grade DDoS mitigation built into every plan. Your bots stay online no matter what, with automatic traffic filtering and attack absorption.",
    },
    {
      icon: <Zap className="h-6 w-6" />,
      title: "Instant Deployment",
      desc: "Get your bot running in seconds. Our automated provisioning system sets up your environment instantly after payment confirmation.",
    },
    {
      icon: <Network className="h-6 w-6" />,
      title: "100Gbps Network",
      desc: "Connected to premium tier-1 networks with up to 100Gbps bandwidth. Ultra-low latency for Discord gateway connections worldwide.",
    },
    {
      icon: <Clock className="h-6 w-6" />,
      title: "99.9% Uptime SLA",
      desc: "Backed by our uptime guarantee with service credits. Redundant systems and automatic failover ensure your bots never go down.",
    },
    {
      icon: <Headphones className="h-6 w-6" />,
      title: "24/7 Expert Support",
      desc: "Our knowledgeable support team is available around the clock via live chat and tickets. Average response time under 15 minutes.",
    },
  ];

  return (
    <section className="relative bg-grid py-20">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/2 top-1/2 h-[500px] w-[500px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#00d4ff]/[0.03] blur-[120px]" />
      </div>
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <div className="text-center">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            Why Choose <span className="gradient-text">JAAT Cloud</span>
          </h2>
          <p className="mt-3 text-muted-foreground">
            Built for performance, designed for reliability
          </p>
        </div>
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f) => (
            <div
              key={f.title}
              className="card-glass card-glass-hover group rounded-2xl border border-white/[0.06] p-6 transition-all duration-300"
            >
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-[#00d4ff]/10 text-[#00d4ff] transition-colors group-hover:bg-[#00d4ff]/20">
                {f.icon}
              </div>
              <h3 className="mb-2 text-lg font-bold">{f.title}</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-white/[0.06] bg-[#0a0a0a]">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div className="lg:col-span-1">
            <a href="#" className="flex items-center gap-2 text-lg font-bold">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br from-[#00d4ff] to-[#7b61ff]">
                <Zap className="h-3.5 w-3.5 text-white" />
              </div>
              JAAT<span className="gradient-text">Cloud</span>
            </a>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              Premium Discord bot hosting powered by enterprise hardware. Trusted by thousands worldwide.
            </p>
          </div>
          {/* Hosting */}
          <div>
            <h4 className="mb-4 text-sm font-semibold">Hosting</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#" className="hover:text-[#00d4ff] transition-colors">Discord Bot Hosting</a></li>
              <li><a href="#" className="hover:text-[#00d4ff] transition-colors">Minecraft Hosting</a></li>
              <li><a href="#" className="hover:text-[#00d4ff] transition-colors">Linux VPS Hosting</a></li>
              <li><a href="#" className="hover:text-[#00d4ff] transition-colors">Dedicated Servers</a></li>
            </ul>
          </div>
          {/* Company */}
          <div>
            <h4 className="mb-4 text-sm font-semibold">Company</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#" className="hover:text-[#00d4ff] transition-colors">About Us</a></li>
              <li><a href="#" className="hover:text-[#00d4ff] transition-colors">Blog</a></li>
              <li><a href="#" className="hover:text-[#00d4ff] transition-colors">Careers</a></li>
              <li><a href="#" className="hover:text-[#00d4ff] transition-colors">Contact</a></li>
            </ul>
          </div>
          {/* Legal */}
          <div>
            <h4 className="mb-4 text-sm font-semibold">Legal</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#" className="hover:text-[#00d4ff] transition-colors">Terms of Service</a></li>
              <li><a href="#" className="hover:text-[#00d4ff] transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-[#00d4ff] transition-colors">SLA</a></li>
              <li><a href="#" className="hover:text-[#00d4ff] transition-colors">AUP</a></li>
            </ul>
          </div>
        </div>
        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-white/[0.06] pt-8 sm:flex-row">
          <p className="text-xs text-muted-foreground">
            &copy; 2026 JAAT Cloud. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <a href="#" className="text-muted-foreground hover:text-[#00d4ff] transition-colors">
              <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24"><path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03z"/></svg>
            </a>
            <a href="#" className="text-muted-foreground hover:text-[#00d4ff] transition-colors">
              <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24"><path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/></svg>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}

/* ─── Page ─── */

export default function Page() {
  return (
    <div className="min-h-screen bg-[#0a0a0a]">
      <Navbar />
      <HeroSection />
      <FeaturesSection />
      <PricingSection />
      <ComparisonSection />
      <Footer />
    </div>
  );
}
